# Picdiet
A copy of Picdiet

Picdiet是一款在线批量压缩图片神器，它不需要后端服务器或者API的支持，仅通过你的浏览器来压缩图片大小，这意味着它压缩图片极快并且不会导致隐私或敏感图片泄漏。

本项目基于原[网站代码](https://www.picdiet.com)修改，支持本地运行和Github Pages
